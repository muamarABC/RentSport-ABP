package id.esaku.rentsport.domain.model

data class UserItem(
    val idUser: String,

    val nama: String?,

    val alamat: String,

    val password: String
)